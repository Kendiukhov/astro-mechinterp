S1 File. Per-experiment results.

Contents
  results/*.json        the recorded output of every experiment reported in the article,
                        one file per experiment
  claims-to-code.md     maps every numbered claim in the article to the experiment script
                        that produced it and the key path in the JSON that holds it

Every figure and every table in the article is regenerated from these files alone, by
experiments/make_paper_figures.py in the accompanying code archive, with no call to the model.
That is deliberate: a figure cannot disagree with the number quoted in the text.

The analysis code that produced these files, and the instructions for rebuilding the public
survey data they derive from, are at https://github.com/Kendiukhov/astro-mechinterp
